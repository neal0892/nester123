from distutils.core import setup

setup   (
        name           ='nester123',
        version         = '1.0.0',
        py_modules    =['nester123'],
        author         = 'neeraj',
	url            = 'https://github.com/neal0892/nester123',
        author_email = 'neal0892@gmail.com',
        description     = 'A simple printer of nested lines',

        )
